# Version History Log

## Version: no auth
**Date:** 2026-03-02
**Status:** Stable version before adding authentication.
**Features:**
- Full architectural and interior design rendering.
- Category-specific smart prompts.
- Multiple visual styles (Conceptual, Artistic, etc.).
- Image comparison and editing tools.
- Referrer policy fixes for external images.
