import React, { useState, useMemo, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ImageEditor } from './components/ImageEditor';
import { HomeScreen } from './components/HomeScreen';
import { ImageViewerModal } from './components/ComparisonSliderModal';
import { MoodboardCreator } from './components/MoodboardCreator';
import PaymentPage from './components/PaymentPage';
import { Category, Style, FurnitureOptionId, EditMode, StyleSubCategory, User, SubscriptionPlan, AIRenderMode, UserProfile, BuildingState, Theme, Language } from './types';
import { FURNITURE_OPTIONS, CATEGORIES } from './constants';
import { generateImage } from './services/geminiService';

function App() {
  // Auth & Subscription State
  const [user, setUser] = useState<User | null>(null);
  const [showPayment, setShowPayment] = useState(false);

  // Settings State
  const [theme, setTheme] = useState<Theme>(() => (localStorage.getItem('rm_theme') as Theme) || 'light');
  const [language, setLanguage] = useState<Language>(() => (localStorage.getItem('rm_lang') as Language) || 'en');

  // Main editor state
  const [activeCategory, setActiveCategory] = useState<Category['id']>('Interiors');
  const [selectedStyle, setSelectedStyle] = useState<Style | null>(null);
  const [geometryValue, setGeometryValue] = useState(50);
  const [selectedFurnitureOption, setSelectedFurnitureOption] = useState<FurnitureOptionId>('change');
  const [buildingState, setBuildingState] = useState<BuildingState>('ready');
  const [editMode, setEditMode] = useState<EditMode>('conceptual');
  const [styleSubCategory, setStyleSubCategory] = useState<StyleSubCategory>('preset');
  const [contrastValue, setContrastValue] = useState(0);
  
  // Style Reference Image state
  const [styleReferenceImage, setStyleReferenceImage] = useState<File | null>(null);
  const [styleReferenceImageUrl, setStyleReferenceImageUrl] = useState<string | null>(null);

  // AI Render State
  const [aiRenderBaseImage, setAiRenderBaseImage] = useState<File | null>(null);
  const [aiRenderBaseImageUrl, setAiRenderBaseImageUrl] = useState<string | null>(null);
  const [aiRenderMode, setAiRenderMode] = useState<AIRenderMode>('creative');
  const [aiRenderCreativity, setAiRenderCreativity] = useState(5);
  const [aiRenderResultUrl, setAiRenderResultUrl] = useState<string | null>(null);
  const [isAiRenderLoading, setIsAiRenderLoading] = useState(false);
  const [aiRenderError, setAiRenderError] = useState<string | null>(null);

  // Floorplan State
  const [floorplanBaseImage, setFloorplanBaseImage] = useState<File | null>(null);
  const [floorplanBaseImageUrl, setFloorplanBaseImageUrl] = useState<string | null>(null);
  const [floorplanResultUrl, setFloorplanResultUrl] = useState<string | null>(null);
  const [isFloorplanLoading, setIsFloorplanLoading] = useState(false);
  const [floorplanError, setFloorplanError] = useState<string | null>(null);
  
  // Modal state
  const [isImageViewerOpen, setIsImageViewerOpen] = useState(false);
  const [viewerImageUrl, setViewerImageUrl] = useState<string | null>(null);

  // Persistence
  useEffect(() => {
    const savedUser = localStorage.getItem('rm_user');
    if (savedUser) setUser(JSON.parse(savedUser));
  }, []);

  // Theme effect
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('rm_theme', theme);
  }, [theme]);

  // Language effect
  useEffect(() => {
    localStorage.setItem('rm_lang', language);
  }, [language]);

  const handleLogin = (userData: User) => {
    setUser(userData);
    localStorage.setItem('rm_user', JSON.stringify(userData));
  };

  const handleProfileSelect = (profile: UserProfile) => {
    // Simulate direct login based on profile selection
    const isPro = profile === 'arkitecna';
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      email: isPro ? 'studio@arkitecna.com' : 'guest@example.com',
      name: isPro ? 'Arkitecna Studio' : 'Guest User',
      plan: isPro ? 'pro' : 'free',
      credits: isPro ? 1000 : 5,
    };
    handleLogin(newUser);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('rm_user');
    resetEditorState();
  };

  const handleUpgrade = (plan: SubscriptionPlan) => {
    if (user) {
      const updatedUser = { ...user, plan };
      setUser(updatedUser);
      localStorage.setItem('rm_user', JSON.stringify(updatedUser));
      setShowPayment(false);
    }
  };

  const handleCategoryClick = (id: Category['id']) => {
    const category = CATEGORIES.find(c => c.id === id);
    if (category?.isPro && (!user || user.plan === 'free')) {
      setShowPayment(true);
      return;
    }
    setActiveCategory(id);
    setSelectedStyle(null);
    setEditMode('conceptual');
    setBuildingState('ready'); // Reset building state on category change
    setStyleSubCategory('preset');
  };

  const handleStyleReferenceImageChange = (file: File | null) => {
    if (styleReferenceImageUrl) URL.revokeObjectURL(styleReferenceImageUrl);
    if (file) {
      setStyleReferenceImage(file);
      setStyleReferenceImageUrl(URL.createObjectURL(file));
    } else {
      setStyleReferenceImage(null);
      setStyleReferenceImageUrl(null);
    }
  };

  const handleAiRenderBaseImageChange = (file: File | null) => {
    if (aiRenderBaseImageUrl) URL.revokeObjectURL(aiRenderBaseImageUrl);
    if (file) {
      setAiRenderBaseImage(file);
      setAiRenderBaseImageUrl(URL.createObjectURL(file));
    } else {
      setAiRenderBaseImage(null);
      setAiRenderBaseImageUrl(null);
    }
    setAiRenderResultUrl(null);
    setAiRenderError(null);
  };

  const handleFloorplanBaseImageChange = (file: File | null) => {
    if (floorplanBaseImageUrl) URL.revokeObjectURL(floorplanBaseImageUrl);
    if (file) {
      setFloorplanBaseImage(file);
      setFloorplanBaseImageUrl(URL.createObjectURL(file));
    } else {
      setFloorplanBaseImage(null);
      setFloorplanBaseImageUrl(null);
    }
    setFloorplanResultUrl(null);
    setFloorplanError(null);
  };

  const resetEditorState = () => {
    setActiveCategory('Interiors');
    setSelectedStyle(null);
    setGeometryValue(50);
    setSelectedFurnitureOption('change');
    setBuildingState('ready');
    setEditMode('conceptual');
    setStyleSubCategory('preset');
    setContrastValue(0);
    handleStyleReferenceImageChange(null);
    handleAiRenderBaseImageChange(null);
    handleFloorplanBaseImageChange(null);
    setShowPayment(false);
  };

  const handleAIRenderGenerate = async () => {
    if (!aiRenderBaseImage || !user) return;
    
    if (user.plan === 'free' && user.credits <= 0) {
      setShowPayment(true);
      return;
    }

    setIsAiRenderLoading(true);
    setAiRenderError(null);
    
    let prompt = aiRenderMode === 'keep-texture' 
      ? "Professionally render this architectural image, keeping the existing textures..."
      : "Creatively render this architectural image...";

    const geometryValue = (10 - aiRenderCreativity) * 10;

    try {
        const base64 = await generateImage(aiRenderBaseImage, prompt, geometryValue, 0);
        setAiRenderResultUrl(`data:image/png;base64,${base64}`);
        
        // Use credit
        if (user.plan === 'free') {
          const updatedUser = { ...user, credits: user.credits - 1 };
          setUser(updatedUser);
          localStorage.setItem('rm_user', JSON.stringify(updatedUser));
        }
    } catch (e: any) {
        setAiRenderError(e.message || "Failed to generate render.");
    } finally {
        setIsAiRenderLoading(false);
    }
  };

  const handleFloorplanGenerate = async () => {
    if (!floorplanBaseImage || !user || !selectedStyle) return;

    if (user.plan === 'free' && user.credits <= 0) {
      setShowPayment(true);
      return;
    }

    setIsFloorplanLoading(true);
    setFloorplanError(null);

    try {
      // Use existing generateImage function but with floorplan specific prompt and geometry value
      const base64 = await generateImage(floorplanBaseImage, selectedStyle.prompt, geometryValue, 0);
      setFloorplanResultUrl(`data:image/png;base64,${base64}`);

      // Use credit
      if (user.plan === 'free') {
        const updatedUser = { ...user, credits: user.credits - 1 };
        setUser(updatedUser);
        localStorage.setItem('rm_user', JSON.stringify(updatedUser));
      }
    } catch (e: any) {
      setFloorplanError(e.message || "Failed to generate floorplan.");
    } finally {
      setIsFloorplanLoading(false);
    }
  };

  if (!user) {
    return <HomeScreen onProfileSelect={handleProfileSelect} />;
  }

  if (showPayment) {
    return <PaymentPage onSelectPlan={handleUpgrade} onBack={() => setShowPayment(false)} />;
  }
  
  return (
    <div className="h-screen w-screen flex flex-col bg-white font-sans antialiased">
      <Header onGoHome={resetEditorState} user={user} onLogout={handleLogout} />
      
      <div className="flex flex-col md:flex-row flex-1 min-h-0">
          <Sidebar
            activeCategory={activeCategory}
            onCategoryClick={handleCategoryClick}
            selectedStyleId={selectedStyle?.id || null}
            onApplyStyle={(s) => setSelectedStyle(s)}
            geometryValue={geometryValue}
            onSetGeometryValue={setGeometryValue}
            selectedFurnitureOption={selectedFurnitureOption}
            onSetFurnitureOption={setSelectedFurnitureOption}
            buildingState={buildingState}
            onSetBuildingState={setBuildingState}
            editMode={editMode}
            onSetEditMode={setEditMode}
            styleSubCategory={styleSubCategory}
            onSetStyleSubCategory={setStyleSubCategory}
            styleReferenceImageUrl={styleReferenceImageUrl}
            onStyleReferenceImageChange={handleStyleReferenceImageChange}
            aiRenderBaseImageUrl={aiRenderBaseImageUrl}
            onAiRenderBaseImageChange={handleAiRenderBaseImageChange}
            aiRenderMode={aiRenderMode}
            onSetAiRenderMode={setAiRenderMode}
            aiRenderCreativity={aiRenderCreativity}
            onSetAiRenderCreativity={setAiRenderCreativity}
            onAIRenderGenerate={handleAIRenderGenerate}
            isAiRenderLoading={isAiRenderLoading}
            user={user}
            // Floorplan props
            floorplanBaseImageUrl={floorplanBaseImageUrl}
            onFloorplanBaseImageChange={handleFloorplanBaseImageChange}
            onFloorplanGenerate={handleFloorplanGenerate}
            isFloorplanLoading={isFloorplanLoading}
          />
        
          {activeCategory === 'Moodboard' ? (
            <MoodboardCreator 
              onImageDoubleClick={(url) => { setViewerImageUrl(url); setIsImageViewerOpen(true); }}
            />
          ) : (
            <ImageEditor
              activeCategory={activeCategory}
              onImageDoubleClick={(url) => { setViewerImageUrl(url); setIsImageViewerOpen(true); }}
              selectedStyle={selectedStyle}
              geometryValue={geometryValue}
              selectedFurnitureOption={selectedFurnitureOption}
              buildingState={buildingState}
              furniturePrompt={FURNITURE_OPTIONS.find(o => o.id === selectedFurnitureOption)?.prompt || ''}
              editMode={editMode}
              onSetEditMode={setEditMode}
              onReset={resetEditorState}
              styleSubCategory={styleSubCategory}
              isMoodboard={false}
              contrastValue={contrastValue}
              onSetContrastValue={setContrastValue}
              styleReferenceImage={styleReferenceImage}
              externalResultUrl={
                activeCategory === 'AI Render' ? aiRenderResultUrl :
                activeCategory === 'Floorplan' ? floorplanResultUrl : null
              }
              externalBaseUrl={
                activeCategory === 'AI Render' ? aiRenderBaseImageUrl :
                activeCategory === 'Floorplan' ? floorplanBaseImageUrl : null
              }
              externalLoading={
                activeCategory === 'AI Render' ? isAiRenderLoading :
                activeCategory === 'Floorplan' ? isFloorplanLoading : false
              }
              externalError={
                activeCategory === 'AI Render' ? aiRenderError :
                activeCategory === 'Floorplan' ? floorplanError : null
              }
            />
          )}
      </div>

      <ImageViewerModal
        isOpen={isImageViewerOpen}
        onClose={() => setIsImageViewerOpen(false)}
        imageUrl={viewerImageUrl}
      />
    </div>
  );
}

export default App;