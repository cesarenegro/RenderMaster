import React from 'react';

export type SubscriptionPlan = 'free' | 'pro' | 'enterprise';

export interface User {
  id: string;
  email: string;
  name: string;
  plan: SubscriptionPlan;
  credits: number;
}

export interface Category {
  id: 'Interiors' | 'Exteriors' | 'Moodboard' | 'AI Render' | 'Floorplan';
  Icon: React.FC<React.SVGProps<SVGSVGElement>>;
  isPro?: boolean;
}

export interface Style {
  id: string;
  name: string;
  image: string;
  prompt: string;
}

export type EditMode = 'conceptual' | 'styles' | 'prompt';

export type StyleSubCategory = 'preset' | 'conceptual' | 'moodboard';

export type FurnitureOptionId = 'keep' | 'change' | 'empty';

export type BuildingState = 'raw' | 'ready';

export type AIRenderMode = 'keep-texture' | 'creative';

export interface FurnitureOption {
  id: FurnitureOptionId;
  label: string;
  prompt: string;
  Icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

export type UserProfile = 'user' | 'arkitecna';

export type Theme = 'light' | 'dark';
export type Language = 'en' | 'it' | 'ru';
